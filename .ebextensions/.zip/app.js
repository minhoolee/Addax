var express = require('express')
var app = express()
var AWS = require('aws-sdk');
var uuid4 = require('uuid/v4')
var cors = require('cors')
//var multer  = require('multer')
const fileUpload = require('express-fileupload');



const bodyParser = require('body-parser');

var accessKeyId = 'AKIAIYY4M5SFDFKW4H7A';
var secretAccessKey = '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';
AWS.config.region = 'us-west-2';
AWS.config.update({
	accessKeyId: accessKeyId,
	secretAccessKey: secretAccessKey
});

var s3 = new AWS.S3();
var s3bucket = new AWS.S3({params:{Bucket:'addax'}});
var fs = require('fs');
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());
app.use(cors())
app.use(fileUpload());



app.post('/upload',function(req,res){
	console.log("ASDFSDFASDF")
	info = req.files.info
	video = req.files.video
	

	var uuid = uuid4()
	var infoName = "all/" + uuid + "/info.json"
	var infoOptions = {
        Key: infoName,
        Body: info,
        ACL: "public-read",
        ContentType: "application/json" 
   }

   var videoName = "all/" + uuid + "/video.mp4"
   var videoOptions = {
        Key: videoName,
        Body: data,
        ACL: "public-read",
        ContentType: "video/mp4" 
   }

    
    s3bucket.putObject(infoOptions,function (err, data) {
    	s3bucket.putObject(videOpions,function(err,data){
    		res.send(200)
    	})
	});



});
app.get('/topTen',function(req,res){
	var params = {
		Bucket: "addax",		
		Key: "topTen.json"
	};
	
	s3.getObject(params,function(err,data){
		if (err){
			console.log(err, err.stack); // an error occurred
		}else{
			console.log(data.Body.toString())
			data = data.Body.toString()
			res.send(data)
		}
	});
});

app.get('/all', function (req, res) {
	
	var params = {
		Bucket: "addax",
		Delimiter: '/',
		Prefix:'all/'
		
	};
	 
	var commonPrefixes = []
	var info = []
	s3.listObjects(params, function(err, data) {
		if (err){
			console.log(err, err.stack); // an error occurred
		}else{   
			commonPrefixes = data.CommonPrefixes;  
			//console.log(commonPrefixes)
			commonPrefixes = commonPrefixes.map(function(prefix){
				return prefix.Prefix;
			});
			var itemsProcessed = 0;
			commonPrefixes.forEach(function(key){
				
				Key = key + "info.json"
				var params = {
					Bucket: "addax",		
					Key: Key
				};
				
				s3.getObject(params, function(err, data) {
					if (err){
						console.log(err, err.stack); // an error occurred
					}else{
			

					console.log(data.Body.toString())
					info.push(JSON.parse(data.Body.toString()))
					itemsProcessed++
					if(itemsProcessed===commonPrefixes.length){
						res.send(info)
					}
			

					}	   
				});
				
			});
			
			
			

		}    
		
		
	});  
	
	
  
	
})




app.listen( process.env.PORT || 3000);
